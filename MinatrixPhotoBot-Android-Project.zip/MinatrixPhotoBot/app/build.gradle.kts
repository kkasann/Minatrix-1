plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.minatrixphotobot"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.minatrixphotobot"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "0.1"
    }
}

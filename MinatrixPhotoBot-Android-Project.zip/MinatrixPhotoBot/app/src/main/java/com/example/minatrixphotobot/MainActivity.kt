package com.example.minatrixphotobot

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : Activity() {
    private var selectedPhoto: Uri? = null
    private val recipients = mutableListOf<String>()
    private lateinit var photoPreview: ImageView
    private lateinit var photoStatus: TextView
    private lateinit var recipientList: TextView
    private lateinit var recipientInput: EditText
    private lateinit var consentBox: CheckBox
    private var nextRecipient = 0

    private val photoPicker = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            selectedPhoto = uri
            photoPreview.setImageURI(uri)
            photoStatus.text = "Выбрана одна фотография"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 28, 24, 24)
        }

        content.addView(TextView(this).apply {
            text = "Minatrix Photo Bot"
            textSize = 25f
            gravity = Gravity.CENTER
        }, matchWidth())

        content.addView(TextView(this).apply {
            text = "Подготовка публикаций для выбранных получателей"
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 16)
        }, matchWidth())

        photoPreview = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setImageResource(android.R.drawable.ic_menu_gallery)
            contentDescription = "Предпросмотр фотографии"
        }
        content.addView(photoPreview, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 220
        ))

        photoStatus = TextView(this).apply {
            text = "Фотография не выбрана"
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 8)
        }
        content.addView(photoStatus, matchWidth())

        content.addView(Button(this).apply {
            text = "Выбрать одно фото"
            setOnClickListener { photoPicker.launch("image/*") }
        }, matchWidth())

        content.addView(TextView(this).apply {
            text = "Получатели"
            textSize = 19f
            setPadding(0, 18, 0, 8)
        }, matchWidth())

        recipientInput = EditText(this).apply {
            hint = "Ник пользователя Minatrix FM"
            singleLine = true
        }
        content.addView(recipientInput, matchWidth())

        consentBox = CheckBox(this).apply {
            text = "Получатель согласился получить публикацию"
        }
        content.addView(consentBox, matchWidth())

        content.addView(Button(this).apply {
            text = "Добавить в очередь"
            setOnClickListener { addRecipient() }
        }, matchWidth())

        recipientList = TextView(this).apply {
            text = "Очередь пуста"
            textSize = 14f
            setPadding(0, 10, 0, 10)
        }
        content.addView(recipientList, matchWidth())

        content.addView(Button(this).apply {
            text = "Удалить всех из очереди"
            setOnClickListener {
                recipients.clear()
                nextRecipient = 0
                refreshRecipients()
            }
        }, matchWidth())

        content.addView(Button(this).apply {
            text = "Скопировать следующего получателя"
            setOnClickListener { copyNextRecipient() }
        }, matchWidth())

        content.addView(Button(this).apply {
            text = "Открыть Minatrix FM в Chrome"
            setOnClickListener { openMinatrix() }
        }, matchWidth())

        content.addView(TextView(this).apply {
            text = "Приложение подготавливает очередь и открывает сайт. Публикацию проверь и выполни вручную на странице пользователя. Автоматическая отправка всем пользователям сайта не включена."
            textSize = 13f
            setPadding(0, 18, 0, 0)
        }, matchWidth())

        val scroll = ScrollView(this).apply { addView(content) }
        setContentView(scroll)
    }

    private fun addRecipient() {
        val nick = recipientInput.text.toString().trim()
        if (nick.isEmpty()) {
            toast("Введи ник пользователя")
            return
        }
        if (!consentBox.isChecked) {
            toast("Сначала подтверди согласие получателя")
            return
        }
        if (recipients.any { it.equals(nick, ignoreCase = true) }) {
            toast("Этот пользователь уже в очереди")
            return
        }
        recipients.add(nick)
        recipientInput.text.clear()
        consentBox.isChecked = false
        refreshRecipients()
    }

    private fun refreshRecipients() {
        recipientList.text = if (recipients.isEmpty()) {
            "Очередь пуста"
        } else {
            recipients.mapIndexed { index, nick ->
                "${index + 1}. $nick" + if (index == nextRecipient) "  ← следующий" else ""
            }.joinToString("\n")
        }
    }

    private fun copyNextRecipient() {
        if (selectedPhoto == null) {
            toast("Сначала выбери фотографию")
            return
        }
        if (nextRecipient >= recipients.size) {
            toast("Очередь закончилась")
            return
        }
        val nick = recipients[nextRecipient]
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Minatrix recipient", nick))
        nextRecipient++
        refreshRecipients()
        toast("Ник $nick скопирован. Открой сайт и выполни публикацию вручную.")
    }

    private fun openMinatrix() {
        val url = Uri.parse("https://minatrix.fm/")
        val chromeIntent = Intent(Intent.ACTION_VIEW, url).apply {
            setPackage("com.android.chrome")
        }
        try {
            startActivity(chromeIntent)
        } catch (_: Exception) {
            startActivity(Intent(Intent.ACTION_VIEW, url))
        }
    }

    private fun matchWidth() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = 8 }

    private fun toast(message: String) =
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}
